from django.urls import path
from . import views

urlpatterns = [
    path('', views.my_view,name="home"),
    path("submit_registration/",views.check_registration,name="register"),
    path("login/",views.check_login,name="login"),
    path("signing_in/",views.signing_in,name="signin")
]